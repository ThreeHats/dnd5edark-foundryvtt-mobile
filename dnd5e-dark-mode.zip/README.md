Custom fork of dnd5e dark mode with other small changes.
Designed to work with [modified version](https://github.com/JustAnotherIdea/simplemobileV11) of simple mobile by Handyfon.