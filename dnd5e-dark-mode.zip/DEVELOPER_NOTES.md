# Developer Notes

## Scripts

To overwrite an existing local installation with new files:
```bash
./script/dev-copy.sh /path/to/foundry-user-data/data/Data/modules/dnd5e-dark-mode/
```
